package gameOfLife;

public record Cell (int row, int col) {}
    //Flyweight design pattern
