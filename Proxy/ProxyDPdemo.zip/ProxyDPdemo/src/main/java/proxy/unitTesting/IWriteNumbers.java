package proxy.unitTesting;
public interface IWriteNumbers {
    void write(int n);
    void close();
}
