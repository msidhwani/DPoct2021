package springAspectDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class Application {
  public static void mainForSpringAspectDemo(String[] args) {
    ApplicationContext ctx = SpringApplication.run(Application.class, args);
    Cache c = ctx.getBean(Cache.class);
    c.setCacheSize(1);
  }
}
